package org.capg.boot;

import java.util.List;
import java.util.Scanner;

import org.capg.model.Customer;
import org.capg.service.CustomerServiceImpl;
import org.capg.service.ICustomerService;
import org.capg.view.UserInteraction;

public class BootClass {

	static Scanner scanner=new Scanner(System.in);
	
	public static void main(String[] args) {
		ICustomerService customerService=new CustomerServiceImpl();
		UserInteraction userInteraction=new UserInteraction();
		
		int  choice;
		String option;
		do {
		System.out.println("1.Create Customer");
		System.out.println("2.List Customers");
		System.out.println("Enter Your choice:");
		choice=scanner.nextInt();
				
			switch(choice) {		
			case 1:
				
				int count=customerService.getAllCustomers().size();
				
				Customer customer=userInteraction.getCustomerDetails();
				customerService.createCustomer(customer);
				
				
				if(count==customerService.getAllCustomers().size())
					userInteraction.printError("Customer Creation Error! Please Try Again!");
					
				
				break;
			case 2:
				
				List<Customer> customers= customerService.getAllCustomers();
				userInteraction.printCustomers(customers);
				break;
			default:
				System.out.println("Sorry! Invalid Choice");
				System.exit(0);
			
			}
			System.out.println("Do you wish to contine?[y|n]:");
			option=scanner.next();
			
		}while(option.charAt(0)=='y' || option.charAt(0)=='Y');
		
		
		
		//System.out.println(customer);
	}

}
