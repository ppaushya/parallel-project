package org.xyz.util;

import org.xyz.view.*;
public class Utility {

	public int generateRandomNumber()
	{
		return (int)(Math.random()*1000)/255;
	}
	
	public static boolean isValidFirstName(String fname)
	{
		return fname.matches("[a-zA-Z]{3,}");
	}
	
	public static boolean isValidLastName(String lname)
	{
		return lname.matches("[a-zA-Z]{3,}");
	}

	public static boolean isValidEmailId(String email) {


		return email.matches("[a-zA-Z0-9]{1,}@[a-zA-Z]{1,}.[a-zA-Z]+") ;
	}

	public static boolean isValidMobileNumber(String mobile) {
		
		return mobile.matches("[1-9][0-9]{9}");
	}

	public static boolean isValidDateOfBirth(String dob) {
		
		return dob.matches("[0-3][0-9]/[0-1][0-9]/[1-2][0-9][0-9][0-9]");
	}

	public static boolean isValidPinCode(String pin) {
		
		return pin.matches("[0-9]{6}");
	}
}