package org.xyz.boot;

import org.xyz.view.UserInteraction;
public class BootClass {

	public static void main(String[] args) {
		
		UserInteraction userInteraction= new UserInteraction();
		
		userInteraction.printCustomerDetails();

	}

}
