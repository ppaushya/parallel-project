package org.xyz.dao;

import java.util.List;

import org.xyz.modal.Customer;

public interface ICustomerDao {

}
