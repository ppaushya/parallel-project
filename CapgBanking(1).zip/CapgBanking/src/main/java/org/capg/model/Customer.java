package org.capg.model;

import java.time.LocalDate;

public class Customer {

	private int customerId;
	private String FirstName;
	private String LastName;
	private LocalDate dateOfBirth;
	private String emailId;
	private String mobileNumber;
	private String password;
	private Address address;
	
	public Customer() {
		
	}
	
	
	public Customer(int customerId, String firstName, String lastName, LocalDate dateOfBirth, String emailId,
			String mobileNumber, String password, Address address) {
		super();
		this.customerId = customerId;
		FirstName = firstName;
		LastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.emailId = emailId;
		this.mobileNumber = mobileNumber;
		this.password = password;
		this.address = address;
	}


	public Customer(int customerId, String firstName, String lastName, LocalDate dateOfBirth, String emailId,
			String mobileNumber, String password) {
		super();
		this.customerId = customerId;
		FirstName = firstName;
		LastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.emailId = emailId;
		this.mobileNumber = mobileNumber;
		this.password = password;
	}
	
	
	
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", FirstName=" + FirstName + ", LastName=" + LastName
				+ ", dateOfBirth=" + dateOfBirth + ", emailId=" + emailId + ", mobileNumber=" + mobileNumber
				+ ", password=" + password + ", address=" + address + "]";
	}

	
	
	public Address getAddress() {
		return address;
	}


	public void setAddress(Address address) {
		this.address = address;
	}


	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
	
}
