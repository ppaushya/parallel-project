package org.cap.boot;



public class AccountTransaction {

	
	public static long generateAccountNo() {
		return (long)(Math.random()*10000)/10;
	}
	
	/*public static void main(String[] args) {
		for(int i=0;i<10;i++)
			System.out.println(generateAccountNo());
	}*/
	
}
